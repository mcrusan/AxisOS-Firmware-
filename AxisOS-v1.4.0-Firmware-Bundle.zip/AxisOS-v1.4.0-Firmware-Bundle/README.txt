AxisOS v1.4.0 Firmware Release
==============================

Thank you for downloading the AxisOS v1.4.0 firmware bundle.

This package contains:
- AxisOS v1.4.0 Flashing Guide (PDF)
- Firmware manifest files
- Source bundle reference
- File purpose and file content CSVs

This release is intended for:
- Pico2W-based AxisOS nodes
- Development, testing, and early adopter evaluation
- Users who want a reproducible, versioned firmware snapshot

Flashing Instructions:
See "AxisOS v1.4.0 Flashing Guide.pdf" for complete steps.

Versioning:
This release is tagged as v1.4.0 and represents the current stable build.

Notes:
This is an early release and may contain minor typos or formatting issues.
Functionality is complete and validated.

Thank you for supporting AxisOS.
